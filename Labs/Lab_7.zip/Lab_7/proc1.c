#include <stdio.h>
#include <stdlib.h>

int sum(int m, int n){

		return (m + n);
	}

int main() {
	int math = sum(10, 5);

	printf("%d\n", math);



return 0;
}